package com.chromelite.anonymous.privacy

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import com.chromelite.anonymous.R
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicInteger

/**
 * Blocks ad/tracker requests at the network level, before the WebView engine
 * fetches them. This is more effective than CSS-hiding: the request never
 * leaves the device, so it also stops fingerprinting beacons and analytics
 * pings, not just visible banners.
 *
 * Domains are loaded once from res/raw/blocklist.txt into a HashSet for O(1)
 * suffix lookups (fast enough to run on every single sub-resource request).
 */
class AdTrackerBlocker private constructor(private val blockedDomains: HashSet<String>) {

    /** Running counter of requests blocked in the current session (shown in the UI). */
    val blockedCount = AtomicInteger(0)

    /** Kill switch: user can disable blocking from the 3-dot menu. */
    var isEnabled: Boolean = true

    /**
     * Returns a blank 204 response for blocked requests (fed to
     * shouldInterceptRequest), or null to let the request through untouched.
     */
    fun intercept(request: WebResourceRequest): WebResourceResponse? {
        if (!isEnabled) return null
        val host = request.url.host ?: return null
        if (isBlocked(host)) {
            blockedCount.incrementAndGet()
            return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
        }
        return null
    }

    private fun isBlocked(host: String): Boolean {
        // Suffix match: "ads.doubleclick.net" is blocked because it ends in
        // "doubleclick.net", without needing every subdomain listed.
        var h = host
        while (true) {
            if (blockedDomains.contains(h)) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
        }
    }

    companion object {
        fun loadFrom(context: Context): AdTrackerBlocker {
            val set = HashSet<String>()
            context.resources.openRawResource(R.raw.blocklist).bufferedReader().useLines { lines ->
                for (raw in lines) {
                    val line = raw.trim()
                    if (line.isEmpty() || line.startsWith("#")) continue
                    set.add(line.lowercase())
                }
            }
            return AdTrackerBlocker(set)
        }
    }
}
