package com.chromelite.anonymous.privacy

import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Central enforcement point for two privacy guarantees:
 *
 * 1. HTTPS-Only: any http:// navigation or sub-resource is transparently
 *    rewritten to https:// before it's requested. Combined with
 *    network_security_config.xml (cleartextTrafficPermitted="false"), this
 *    means plain HTTP simply cannot happen — either it's upgraded here, or
 *    the OS socket layer refuses the connection.
 * 2. Ad/tracker blocking: every sub-resource request is checked against
 *    [AdTrackerBlocker] before the engine fetches it.
 *
 * @param onProgressHint lets the Activity update the progress bar / lock icon.
 */
class PrivacyWebViewClient(
    private val blocker: AdTrackerBlocker,
    private val onPageStarted: (String) -> Unit,
    private val onPageFinished: (String) -> Unit,
    private val onBlockedCountChanged: (Int) -> Unit
) : WebViewClient() {

    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        val url = request.url
        if (url.scheme == "http") {
            val httpsUrl = url.buildUpon().scheme("https").build()
            view.loadUrl(httpsUrl.toString())
            return true
        }
        return false
    }

    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? {
        // Upgrade sub-resources (images, scripts, iframes) too, not just the
        // top-level navigation, so mixed-content http:// assets never load.
        if (request.url.scheme == "http") {
            return WebResourceResponse("text/plain", "UTF-8", null)
        }
        val blocked = blocker.intercept(request)
        if (blocked != null) {
            onBlockedCountChanged(blocker.blockedCount.get())
        }
        return blocked
    }

    override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
        onPageStarted(url ?: "")
    }

    override fun onPageFinished(view: WebView, url: String?) {
        onPageFinished(url ?: "")
    }

    companion object {
        /** Ensures a bare search term or partial host becomes a real URL. */
        fun normalizeInput(input: String): String {
            val trimmed = input.trim()
            val looksLikeUrl = trimmed.contains(".") && !trimmed.contains(" ")
            return when {
                trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
                looksLikeUrl -> "https://$trimmed"
                else -> {
                    val q = Uri.encode(trimmed)
                    // DuckDuckGo as default search engine: no query logging tied
                    // to a Google account, consistent with the app's privacy goal.
                    "https://duckduckgo.com/?q=$q"
                }
            }
        }
    }
}
