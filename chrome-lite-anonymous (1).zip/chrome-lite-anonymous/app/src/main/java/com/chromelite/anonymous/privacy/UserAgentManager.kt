package com.chromelite.anonymous.privacy

/**
 * Reduces fingerprinting surface by presenting a generic, widely-shared
 * desktop-class User-Agent instead of a string that leaks this exact device
 * model, OS build and app version (the default WebView UA does all three).
 *
 * "Rotating" here means: a new UA is picked once per app session (not per
 * request) from a short list of common, real-world UAs. Rotating on every
 * single request would actually make a device MORE identifiable, since sites
 * would see an impossible browser changing mid-session — session-level
 * rotation is the approach real anti-fingerprinting browsers use.
 */
object UserAgentManager {

    private val POOL = listOf(
        // Generic Windows Chrome desktop UA — the most common UA on the web,
        // so it blends into the largest possible crowd.
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    )

    /** Picked once when the process starts; stable for the app's lifetime. */
    val sessionUserAgent: String by lazy { POOL.random() }
}
