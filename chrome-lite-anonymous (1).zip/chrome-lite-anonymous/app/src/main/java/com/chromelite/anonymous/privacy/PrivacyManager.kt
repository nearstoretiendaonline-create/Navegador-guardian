package com.chromelite.anonymous.privacy

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView

/**
 * Implements "incognito by default": nothing survives a tab close or app
 * exit. Chrome-Lite Anonymous never has a persistent history/cookie mode to
 * turn off — this IS the only mode.
 */
object PrivacyManager {

    /** Applies per-WebView settings that avoid writing to disk in the first place. */
    fun hardenWebView(webView: WebView, context: Context) {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = false          // no localStorage/IndexedDB persistence
        settings.databaseEnabled = false
        settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        settings.saveFormData = false
        settings.setGeolocationEnabled(false)
        settings.userAgentString = UserAgentManager.sessionUserAgent
        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW

        CookieManager.getInstance().apply {
            setAcceptCookie(false)
            setAcceptThirdPartyCookies(webView, false)
        }
    }

    /**
     * Full wipe: cookies, cache, form data, HTML5 storage, and any WebView
     * back/forward history. Called on "Clear data now", on closing the last
     * tab, and from onDestroy so nothing lingers between app launches.
     */
    fun wipeAll(context: Context, webViews: List<WebView>) {
        for (wv in webViews) {
            wv.clearHistory()
            wv.clearCache(true)
            wv.clearFormData()
            wv.clearSslPreferences()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        context.deleteDatabase("webview.db")
        context.deleteDatabase("webviewCache.db")
    }
}
