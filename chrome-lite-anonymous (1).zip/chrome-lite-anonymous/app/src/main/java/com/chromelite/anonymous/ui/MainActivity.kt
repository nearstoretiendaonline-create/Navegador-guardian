package com.chromelite.anonymous.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import com.chromelite.anonymous.R
import com.chromelite.anonymous.core.Tab
import com.chromelite.anonymous.core.TabManager
import com.chromelite.anonymous.databinding.ActivityMainBinding
import com.chromelite.anonymous.databinding.ItemTabBinding
import com.chromelite.anonymous.privacy.AdTrackerBlocker
import com.chromelite.anonymous.privacy.PrivacyManager
import com.chromelite.anonymous.privacy.PrivacyWebViewClient

/**
 * Single-activity browser shell. Chrome-style top bar (omnibox + tab count +
 * 3-dot menu), a lightweight tab strip, and a WebView container that swaps
 * the visible WebView when the active tab changes.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var blocker: AdTrackerBlocker
    private lateinit var tabManager: TabManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        blocker = AdTrackerBlocker.loadFrom(this)
        tabManager = TabManager(this) { renderTabStrip() }

        binding.omnibox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                navigateActiveTab(binding.omnibox.text.toString())
                true
            } else false
        }

        binding.btnBack.setOnClickListener {
            tabManager.activeTab?.webView?.let { if (it.canGoBack()) it.goBack() }
        }
        binding.btnForward.setOnClickListener {
            tabManager.activeTab?.webView?.let { if (it.canGoForward()) it.goForward() }
        }
        binding.btnTabCount.setOnClickListener { openNewTab(focusOmnibox = true) }
        binding.btnMenu.setOnClickListener { showOverflowMenu(it) }

        openNewTab(focusOmnibox = true)
    }

    private fun openNewTab(focusOmnibox: Boolean = false) {
        val tab = tabManager.newTab { createWebView() }
        showTab(tab)
        if (focusOmnibox) {
            binding.omnibox.text?.clear()
            binding.omnibox.requestFocus()
        }
    }

    private fun createWebView(): WebView {
        val webView = WebView(this)
        webView.webViewClient = PrivacyWebViewClient(
            blocker = blocker,
            onPageStarted = { url ->
                runOnUiThread {
                    binding.progressBar.visibility = View.VISIBLE
                    if (url.isNotEmpty()) binding.omnibox.setText(url)
                }
            },
            onPageFinished = { url ->
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    tabManager.activeTab?.let { it.url = url; it.title = webView.title ?: url }
                    renderTabStrip()
                }
            },
            onBlockedCountChanged = { /* hook for a future counter badge */ }
        )
        webView.webChromeClient = android.webkit.WebChromeClient()
        return webView
    }

    private fun navigateActiveTab(input: String) {
        if (input.isBlank()) return
        val url = PrivacyWebViewClient.normalizeInput(input)
        tabManager.activeTab?.webView?.loadUrl(url)
        binding.omnibox.clearFocus()
    }

    private fun showTab(tab: Tab) {
        binding.webViewContainer.removeAllViews()
        (tab.webView.parent as? android.view.ViewGroup)?.removeView(tab.webView)
        binding.webViewContainer.addView(tab.webView)
        binding.omnibox.setText(tab.url)
        renderTabStrip()
    }

    private fun renderTabStrip() {
        binding.tabStrip.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (tab in tabManager.allTabs()) {
            val itemBinding = ItemTabBinding.inflate(inflater, binding.tabStrip, false)
            itemBinding.tabTitle.text = tab.title.ifBlank { getString(R.string.new_tab) }
            itemBinding.root.alpha = if (tab.id == tabManager.activeTab?.id) 1f else 0.6f
            itemBinding.root.setOnClickListener {
                tabManager.switchTo(tab.id)
                tabManager.activeTab?.let { showTab(it) }
            }
            itemBinding.tabClose.setOnClickListener {
                val wasActive = tab.id == tabManager.activeTab?.id
                tabManager.closeTab(tab.id)
                if (tabManager.count == 0) {
                    openNewTab()
                } else if (wasActive) {
                    tabManager.activeTab?.let { showTab(it) }
                }
            }
            binding.tabStrip.addView(itemBinding.root)
        }
        binding.btnTabCount.text = tabManager.count.toString()
    }

    private fun showOverflowMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_browser, popup.menu)
        val blockerItem = popup.menu.findItem(R.id.action_toggle_blocker)
        blockerItem.title = getString(
            R.string.menu_toggle_blocker,
            getString(if (blocker.isEnabled) R.string.blocker_on else R.string.blocker_off)
        )
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_new_tab -> openNewTab(focusOmnibox = true)
                R.id.action_toggle_blocker -> blocker.isEnabled = !blocker.isEnabled
                R.id.action_clear_data -> {
                    val all = tabManager.allTabs().map { it.webView }
                    PrivacyManager.wipeAll(this, all)
                }
                R.id.action_share -> {
                    val url = tabManager.activeTab?.url.orEmpty()
                    if (url.isNotEmpty()) {
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TEXT, url)
                        }
                        startActivity(android.content.Intent.createChooser(intent, null))
                    }
                }
            }
            true
        }
        popup.show()
    }

    /** Nothing must survive process death: wipe everything on the way out. */
    override fun onDestroy() {
        tabManager.closeAll()
        super.onDestroy()
    }
}
