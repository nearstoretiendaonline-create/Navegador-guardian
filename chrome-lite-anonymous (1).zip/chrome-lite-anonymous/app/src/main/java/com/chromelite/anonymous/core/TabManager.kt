package com.chromelite.anonymous.core

import android.content.Context
import android.webkit.WebView
import com.chromelite.anonymous.privacy.PrivacyManager

/** One browser tab: its own isolated WebView instance + display title. */
data class Tab(
    val id: Int,
    val webView: WebView,
    var title: String = "Nueva pestaña",
    var url: String = ""
)

/**
 * Keeps the list of open tabs and which one is active. Each tab gets its own
 * WebView so switching tabs is instant (no reload) and one tab's state never
 * leaks into another's.
 */
class TabManager(private val context: Context, private val onTabsChanged: () -> Unit) {

    private val tabs = mutableListOf<Tab>()
    private var activeIndex: Int = -1
    private var nextId = 1

    val count: Int get() = tabs.size
    val activeTab: Tab? get() = tabs.getOrNull(activeIndex)
    fun allTabs(): List<Tab> = tabs

    fun newTab(webViewFactory: () -> WebView): Tab {
        val webView = webViewFactory()
        PrivacyManager.hardenWebView(webView, context)
        val tab = Tab(id = nextId++, webView = webView)
        tabs.add(tab)
        activeIndex = tabs.lastIndex
        onTabsChanged()
        return tab
    }

    fun switchTo(tabId: Int) {
        val idx = tabs.indexOfFirst { it.id == tabId }
        if (idx >= 0) {
            activeIndex = idx
            onTabsChanged()
        }
    }

    /** Closes a tab and wipes its data immediately — nothing lingers. */
    fun closeTab(tabId: Int) {
        val idx = tabs.indexOfFirst { it.id == tabId }
        if (idx < 0) return
        val tab = tabs[idx]
        PrivacyManager.wipeAll(context, listOf(tab.webView))
        // Must detach from its parent ViewGroup before destroy(), otherwise
        // the WebView can leave a dangling surface behind.
        (tab.webView.parent as? android.view.ViewGroup)?.removeView(tab.webView)
        tab.webView.destroy()
        tabs.removeAt(idx)
        if (activeIndex >= tabs.size) activeIndex = tabs.size - 1
        onTabsChanged()
    }

    fun closeAll() {
        val all = tabs.map { it.webView }
        PrivacyManager.wipeAll(context, all)
        all.forEach {
            (it.parent as? android.view.ViewGroup)?.removeView(it)
            it.destroy()
        }
        tabs.clear()
        activeIndex = -1
        onTabsChanged()
    }
}
